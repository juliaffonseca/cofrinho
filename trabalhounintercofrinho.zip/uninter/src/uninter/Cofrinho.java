package uninter;

// Importar as classes necessárias
import java.util.ArrayList;

public class Cofrinho {

    // Coleção de moedas
    private ArrayList<Moeda> moedas;

    // Construtor
    public Cofrinho() {
        this.moedas = new ArrayList<>();
    }

    /**
     * Adiciona uma moeda no cofrinho.
     */
    public void adicionarMoeda(Moeda moeda) {
        this.moedas.add(moeda);
        System.out.println("Moeda adicionada com sucesso!");
    }

    /**
     * Remove uma moeda específica (caso exista).
     * Aqui, removemos a primeira moeda que tiver o mesmo valor e tipo.
     */
    public boolean removerMoeda(Moeda moeda) {
        for (Moeda m : moedas) {
            if (m.getClass() == moeda.getClass() && m.getValor() == moeda.getValor()) {
                this.moedas.remove(m);
                System.out.println("Moeda removida com sucesso!");
                return true;
            }
        }
        System.out.println("Moeda não encontrada no cofrinho.");
        return false;
    }

    /**
     * Lista todas as moedas dentro do cofrinho.
     */
    public void listagemMoedas() {
        if (moedas.isEmpty()) {
            System.out.println("O cofrinho está vazio!");
        } else {
            System.out.println("Moedas no cofrinho:");
            for (Moeda moeda : moedas) {
                moeda.info();
            }
        }
    }

    /**
     * Calcula o valor total convertido para Real.
     */
    public double calcularTotal() {
        double total = 0;
        for (Moeda m : moedas) {
            total += m.converter();
        }
        return total;
    }

    // (Opcional) Se quiser ter um main para rodar:
    public static void main(String[] args) {
        Cofrinho c = new Cofrinho();  // Corrigido: nome da variável "c"
        
        // Exemplo de teste:
        // c.adicionarMoeda(new Real(1.0));
        // c.listagemMoedas();
        // System.out.println("Total em R$: " + c.calcularTotal());
    }
}
