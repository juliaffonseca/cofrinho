package uninter;

public class Real extends Moeda {

    public Real(double valor) {
        super(valor);
    }

    @Override
    public double converter() {
        // Valor de Real para Real é o mesmo
        return this.valor;
    }

    @Override
    public void info() {
        System.out.println(
            String.format("Moeda: Real | Valor: R$ %.2f", this.valor)
        );
    }
}
