package uninter;

import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Cofrinho cofrinho = new Cofrinho();
        int opcao = 0;

        while (opcao != 5) {
            System.out.println("\n===== COFRINHO DE MOEDAS =====");
            System.out.println("1 - Adicionar Moeda");
            System.out.println("2 - Remover Moeda");
            System.out.println("3 - Listar Moedas");
            System.out.println("4 - Calcular total em Real");
            System.out.println("5 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    adicionarMoedaMenu(cofrinho, sc);
                    break;
                case 2:
                    removerMoedaMenu(cofrinho, sc);
                    break;
                case 3:
                    cofrinho.listagemMoedas();
                    break;
                case 4:
                    double total = cofrinho.calcularTotal();
                    System.out.println(String.format("Total convertido em Real: R$ %.2f", total));
                    break;
                case 5:
                    System.out.println("Encerrando o programa...");
                    break;
                default:
                    System.out.println("Opção inválida!");
                    break;
            }
        }

        sc.close();
    }

    /**
     * Exibe menu para escolher qual tipo de moeda adicionar
     */
    private static void adicionarMoedaMenu(Cofrinho cofrinho, Scanner sc) {
        System.out.println("\nQual tipo de moeda deseja adicionar?");
        System.out.println("1 - Real");
        System.out.println("2 - Dólar");
        System.out.println("3 - Euro");
        int tipo = sc.nextInt();
        System.out.print("Digite o valor da moeda: ");
        double valor = sc.nextDouble();

        Moeda moeda = null;
        switch (tipo) {
            case 1:
                moeda = new Real(valor);
                break;
            case 2:
                moeda = new Dolar(valor);
                break;
            case 3:
                moeda = new Euro(valor);
                break;
            default:
                System.out.println("Tipo inválido!");
                return;
        }

        cofrinho.adicionarMoeda(moeda);
    }

    /**
     * Exibe menu para escolher qual tipo de moeda remover
     */
    private static void removerMoedaMenu(Cofrinho cofrinho, Scanner sc) {
        System.out.println("\nQual tipo de moeda deseja remover?");
        System.out.println("1 - Real");
        System.out.println("2 - Dólar");
        System.out.println("3 - Euro");
        int tipo = sc.nextInt();
        System.out.print("Digite o valor da moeda: ");
        double valor = sc.nextDouble();

        Moeda moeda = null;
        switch (tipo) {
            case 1:
                moeda = new Real(valor);
                break;
            case 2:
                moeda = new Dolar(valor);
                break;
            case 3:
                moeda = new Euro(valor);
                break;
            default:
                System.out.println("Tipo inválido!");
                return;
        }

        cofrinho.removerMoeda(moeda);
    }
}
