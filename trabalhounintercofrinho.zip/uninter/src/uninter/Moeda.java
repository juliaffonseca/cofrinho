package uninter;

public abstract class Moeda {
    
    // Campo protegido, para que as subclasses enxerguem diretamente.
    protected double valor;
    
    // Construtor que recebe o valor
    public Moeda(double valor) {
        this.valor = valor;
    }

    // Se você quer que cada moeda tenha sua forma de conversão, faz abstrato
    public abstract double converter();

    // Se quer que cada moeda imprima sua info de forma diferente, também abstrato
    public abstract void info();

    // Pode ter getters/setters, se precisar
    public double getValor() {
        return valor;
    }
}
