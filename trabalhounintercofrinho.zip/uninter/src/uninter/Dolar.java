package uninter;

public class Dolar extends Moeda {

    public Dolar(double valor) {
        super(valor); // chama o construtor de Moeda
    }

    @Override
    public double converter() {
        double cotacaoDolarParaReal = 5.0; // valor fictício de exemplo
        return this.valor * cotacaoDolarParaReal;
    }

    @Override
    public void info() {
        System.out.println(
            String.format("Moeda: Dólar | Valor: US$ %.2f", this.valor)
        );
    }

    // (Opcional) Se quiser um main para testar Dolar direto:
    public static void main(String[] args) {
        Dolar d = new Dolar(10.0);
        d.info();
        System.out.println("Em Reais: R$ " + d.converter());
    }
}

