package uninter;

public class Euro extends Moeda {

    public Euro(double valor) {
        super(valor);
    }

    @Override
    public double converter() {
        double cotacaoEuroParaReal = 6.0; // exemplo de cotação
        return this.valor * cotacaoEuroParaReal;
    }

    @Override
    public void info() {
        System.out.println(
            String.format("Moeda: Euro | Valor: € %.2f", this.valor)
        );
    }
}

